<?php
/**
 * Plugin Name: WesCarr Health Content Manager
 * Plugin URI: https://wescarrhealth.com
 * Description: Manage editable content for WesCarr Health theme - global settings, contact info, and page content.
 * Version: 1.0.0
 * Author: Elite Dev Studios
 * Author URI: https://elitedevstudios.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wescarhealth-content
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.1
 *
 * @package WescarHealthContent
 */

declare(strict_types=1);

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants.
define( 'WESCARHEALTH_CONTENT_VERSION', '1.0.0' );
define( 'WESCARHEALTH_CONTENT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WESCARHEALTH_CONTENT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WESCARHEALTH_CONTENT_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Main plugin class.
 */
final class WescarHealth_Content {

	/**
	 * Single instance of the class.
	 *
	 * @var WescarHealth_Content|null
	 */
	private static ?WescarHealth_Content $instance = null;

	/**
	 * Get single instance of the class.
	 *
	 * @return WescarHealth_Content
	 */
	public static function get_instance(): WescarHealth_Content {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->load_dependencies();
		$this->init_hooks();
	}

	/**
	 * Load required files.
	 */
	private function load_dependencies(): void {
		require_once WESCARHEALTH_CONTENT_PLUGIN_DIR . 'includes/class-settings.php';
		require_once WESCARHEALTH_CONTENT_PLUGIN_DIR . 'includes/class-helpers.php';
	}

	/**
	 * Initialize hooks.
	 */
	private function init_hooks(): void {
		// Initialize settings.
		add_action( 'init', array( $this, 'init' ) );

		// Load text domain.
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		// Activation hook.
		register_activation_hook( __FILE__, array( $this, 'activate' ) );

		// Deactivation hook.
		register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
	}

	/**
	 * Initialize plugin.
	 */
	public function init(): void {
		// Initialize admin settings.
		if ( is_admin() ) {
			new WescarHealth_Content_Settings();
		}
	}

	/**
	 * Load plugin text domain.
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain(
			'wescarhealth-content',
			false,
			dirname( WESCARHEALTH_CONTENT_PLUGIN_BASENAME ) . '/languages'
		);
	}

	/**
	 * Plugin activation.
	 */
	public function activate(): void {
		// Set default options if they don't exist.
		$defaults = WescarHealth_Content_Helpers::get_defaults();

		foreach ( $defaults as $key => $value ) {
			if ( false === get_option( 'wescarhealth_' . $key ) ) {
				update_option( 'wescarhealth_' . $key, $value );
			}
		}

		// Flush rewrite rules.
		flush_rewrite_rules();
	}

	/**
	 * Plugin deactivation.
	 */
	public function deactivate(): void {
		// Flush rewrite rules.
		flush_rewrite_rules();
	}
}

/**
 * Initialize the plugin.
 *
 * @return WescarHealth_Content
 */
function wescarhealth_content(): WescarHealth_Content {
	return WescarHealth_Content::get_instance();
}

// Initialize.
wescarhealth_content();
