/**
 * WesCarr Health Content Manager - Admin JavaScript
 *
 * Handles media uploader for image fields.
 *
 * @package WescarHealthContent
 */

(function($) {
	'use strict';

	$(document).ready(function() {
		var mediaUploader;

		// Handle upload button click
		$('.wescarhealth-upload-btn').on('click', function(e) {
			e.preventDefault();

			var button = $(this);
			var targetId = button.data('target');
			var targetInput = $('#' + targetId);
			var previewContainer = button.siblings('.wescarhealth-image-preview');
			var removeBtn = button.siblings('.wescarhealth-remove-btn');

			// If the uploader object has already been created, reopen the dialog
			if (mediaUploader) {
				mediaUploader.open();
				return;
			}

			// Create the media uploader
			mediaUploader = wp.media({
				title: 'Select Image',
				button: {
					text: 'Use This Image'
				},
				multiple: false
			});

			// When an image is selected, run a callback
			mediaUploader.on('select', function() {
				var attachment = mediaUploader.state().get('selection').first().toJSON();
				
				// Set the input value to the image URL
				targetInput.val(attachment.url);
				
				// Update the preview
				previewContainer.html('<img src="' + attachment.url + '" alt="" style="max-width: 200px; height: auto;">');
				
				// Show the remove button
				removeBtn.show();
			});

			// Open the uploader dialog
			mediaUploader.open();
		});

		// Handle remove button click
		$('.wescarhealth-remove-btn').on('click', function(e) {
			e.preventDefault();

			var button = $(this);
			var targetId = button.data('target');
			var targetInput = $('#' + targetId);
			var previewContainer = button.siblings('.wescarhealth-image-preview');

			// Clear the input value
			targetInput.val('');
			
			// Clear the preview
			previewContainer.html('');
			
			// Hide the remove button
			button.hide();
		});
	});

})(jQuery);
