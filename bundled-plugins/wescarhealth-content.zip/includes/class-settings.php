<?php
/**
 * Admin settings page for WesCarr Health Content plugin.
 *
 * @package WescarHealthContent
 */

declare(strict_types=1);

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings class for admin page.
 */
class WescarHealth_Content_Settings {

	/**
	 * Option group name.
	 *
	 * @var string
	 */
	private string $option_group = 'wescarhealth_settings';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/**
	 * Add admin menu page.
	 */
	public function add_admin_menu(): void {
		add_menu_page(
			__( 'WesCarr Content', 'wescarhealth-content' ),
			__( 'WesCarr Content', 'wescarhealth-content' ),
			'manage_options',
			'wescarhealth-content',
			array( $this, 'render_settings_page' ),
			'dashicons-edit-page',
			30
		);

		// Add submenu pages for organization.
		add_submenu_page(
			'wescarhealth-content',
			__( 'Contact Info', 'wescarhealth-content' ),
			__( 'Contact Info', 'wescarhealth-content' ),
			'manage_options',
			'wescarhealth-content',
			array( $this, 'render_settings_page' )
		);

		add_submenu_page(
			'wescarhealth-content',
			__( 'Home Page', 'wescarhealth-content' ),
			__( 'Home Page', 'wescarhealth-content' ),
			'manage_options',
			'wescarhealth-homepage',
			array( $this, 'render_homepage_settings' )
		);

		add_submenu_page(
			'wescarhealth-content',
			__( 'Coming Soon', 'wescarhealth-content' ),
			__( 'Coming Soon', 'wescarhealth-content' ),
			'manage_options',
			'wescarhealth-coming-soon',
			array( $this, 'render_coming_soon_settings' )
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_assets( string $hook ): void {
		// Only load on our settings pages.
		if ( strpos( $hook, 'wescarhealth' ) === false ) {
			return;
		}

		wp_enqueue_style(
			'wescarhealth-admin',
			WESCARHEALTH_CONTENT_PLUGIN_URL . 'assets/admin.css',
			array(),
			WESCARHEALTH_CONTENT_VERSION
		);
	}

	/**
	 * Register all settings.
	 */
	public function register_settings(): void {
		// Contact Information settings.
		$contact_fields = array(
			'phone'       => __( 'Phone Number', 'wescarhealth-content' ),
			'email'       => __( 'Email Address', 'wescarhealth-content' ),
			'hours'       => __( 'Hours (Full)', 'wescarhealth-content' ),
			'hours_short' => __( 'Hours (Short)', 'wescarhealth-content' ),
			'booking_url' => __( 'Booking URL', 'wescarhealth-content' ),
		);

		foreach ( $contact_fields as $key => $label ) {
			register_setting(
				$this->option_group,
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}

		// Social Media settings.
		$social_fields = array(
			'facebook_url'  => __( 'Facebook URL', 'wescarhealth-content' ),
			'instagram_url' => __( 'Instagram URL', 'wescarhealth-content' ),
			'linkedin_url'  => __( 'LinkedIn URL', 'wescarhealth-content' ),
			'twitter_url'   => __( 'Twitter/X URL', 'wescarhealth-content' ),
			'youtube_url'   => __( 'YouTube URL', 'wescarhealth-content' ),
		);

		foreach ( $social_fields as $key => $label ) {
			register_setting(
				$this->option_group,
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'esc_url_raw',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}

		// Hero Section settings.
		$hero_fields = array(
			'hero_badge',
			'hero_title_1',
			'hero_title_em',
			'hero_title_2',
			'hero_description',
			'hero_cta_text',
			'hero_cta_secondary',
		);

		foreach ( $hero_fields as $key ) {
			register_setting(
				'wescarhealth_homepage',
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}

		// About Section settings.
		$about_fields = array(
			'about_badge',
			'about_title',
			'about_description',
			'about_list_1',
			'about_list_2',
			'about_list_3',
			'about_cta_text',
		);

		foreach ( $about_fields as $key ) {
			register_setting(
				'wescarhealth_homepage',
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}

		// Stats Section settings.
		$stats_fields = array(
			'stat_1_number',
			'stat_1_suffix',
			'stat_1_label',
			'stat_2_number',
			'stat_2_suffix',
			'stat_2_label',
			'stat_3_number',
			'stat_3_suffix',
			'stat_3_label',
			'stat_4_number',
			'stat_4_suffix',
			'stat_4_label',
		);

		foreach ( $stats_fields as $key ) {
			register_setting(
				'wescarhealth_homepage',
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}

		// CTA Section settings.
		$cta_fields = array(
			'cta_title',
			'cta_description',
			'cta_button_text',
		);

		foreach ( $cta_fields as $key ) {
			register_setting(
				'wescarhealth_homepage',
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}

		// Trust Badge settings.
		$trust_fields = array(
			'trust_rating',
			'trust_text',
			'trust_count',
		);

		foreach ( $trust_fields as $key ) {
			register_setting(
				'wescarhealth_homepage',
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}

		// Coming Soon settings.
		$coming_soon_fields = array(
			'coming_soon_badge',
			'coming_soon_title_1',
			'coming_soon_title_em',
			'coming_soon_title_2',
			'coming_soon_description',
		);

		foreach ( $coming_soon_fields as $key ) {
			register_setting(
				'wescarhealth_coming_soon',
				'wescarhealth_' . $key,
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => WescarHealth_Content_Helpers::get_defaults()[ $key ] ?? '',
				)
			);
		}
	}

	/**
	 * Render the main settings page (Contact Info).
	 */
	public function render_settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Check if settings were saved.
		if ( isset( $_GET['settings-updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			add_settings_error(
				'wescarhealth_messages',
				'wescarhealth_message',
				__( 'Settings saved.', 'wescarhealth-content' ),
				'updated'
			);
		}

		?>
		<div class="wrap wescarhealth-admin">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

			<?php settings_errors( 'wescarhealth_messages' ); ?>

			<div class="wescarhealth-admin__intro">
				<p><?php esc_html_e( 'Manage your site\'s contact information and social media links. These values are used throughout the website.', 'wescarhealth-content' ); ?></p>
			</div>

			<form action="options.php" method="post">
				<?php settings_fields( $this->option_group ); ?>

				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'Contact Information', 'wescarhealth-content' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_phone"><?php esc_html_e( 'Phone Number', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_phone" name="wescarhealth_phone" value="<?php echo esc_attr( get_option( 'wescarhealth_phone' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Main contact phone number displayed on the site.', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_email"><?php esc_html_e( 'Email Address', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="email" id="wescarhealth_email" name="wescarhealth_email" value="<?php echo esc_attr( get_option( 'wescarhealth_email' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Main contact email address.', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hours"><?php esc_html_e( 'Hours (Full)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hours" name="wescarhealth_hours" value="<?php echo esc_attr( get_option( 'wescarhealth_hours' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Full hours text, e.g., "6am - Midnight, 7 Days"', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hours_short"><?php esc_html_e( 'Hours (Short)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hours_short" name="wescarhealth_hours_short" value="<?php echo esc_attr( get_option( 'wescarhealth_hours_short' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Short hours text for compact displays, e.g., "6am - Midnight"', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_booking_url"><?php esc_html_e( 'Booking URL', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="url" id="wescarhealth_booking_url" name="wescarhealth_booking_url" value="<?php echo esc_attr( get_option( 'wescarhealth_booking_url' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'URL for appointment booking (Tebra or other platform).', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'Social Media', 'wescarhealth-content' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_facebook_url"><?php esc_html_e( 'Facebook URL', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="url" id="wescarhealth_facebook_url" name="wescarhealth_facebook_url" value="<?php echo esc_attr( get_option( 'wescarhealth_facebook_url' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_instagram_url"><?php esc_html_e( 'Instagram URL', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="url" id="wescarhealth_instagram_url" name="wescarhealth_instagram_url" value="<?php echo esc_attr( get_option( 'wescarhealth_instagram_url' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_linkedin_url"><?php esc_html_e( 'LinkedIn URL', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="url" id="wescarhealth_linkedin_url" name="wescarhealth_linkedin_url" value="<?php echo esc_attr( get_option( 'wescarhealth_linkedin_url' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_twitter_url"><?php esc_html_e( 'Twitter/X URL', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="url" id="wescarhealth_twitter_url" name="wescarhealth_twitter_url" value="<?php echo esc_attr( get_option( 'wescarhealth_twitter_url' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Leave empty to hide.', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_youtube_url"><?php esc_html_e( 'YouTube URL', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="url" id="wescarhealth_youtube_url" name="wescarhealth_youtube_url" value="<?php echo esc_attr( get_option( 'wescarhealth_youtube_url' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Leave empty to hide.', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<?php submit_button( __( 'Save Settings', 'wescarhealth-content' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the homepage settings page.
	 */
	public function render_homepage_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_GET['settings-updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			add_settings_error(
				'wescarhealth_messages',
				'wescarhealth_message',
				__( 'Settings saved.', 'wescarhealth-content' ),
				'updated'
			);
		}

		?>
		<div class="wrap wescarhealth-admin">
			<h1><?php esc_html_e( 'Home Page Content', 'wescarhealth-content' ); ?></h1>

			<?php settings_errors( 'wescarhealth_messages' ); ?>

			<div class="wescarhealth-admin__intro">
				<p><?php esc_html_e( 'Edit the text content displayed on the home page sections.', 'wescarhealth-content' ); ?></p>
			</div>

			<form action="options.php" method="post">
				<?php settings_fields( 'wescarhealth_homepage' ); ?>

				<!-- Hero Section -->
				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'Hero Section', 'wescarhealth-content' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_hero_badge"><?php esc_html_e( 'Badge Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hero_badge" name="wescarhealth_hero_badge" value="<?php echo esc_attr( get_option( 'wescarhealth_hero_badge' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hero_title_1"><?php esc_html_e( 'Title (Part 1)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hero_title_1" name="wescarhealth_hero_title_1" value="<?php echo esc_attr( get_option( 'wescarhealth_hero_title_1' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Text before the emphasized part.', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hero_title_em"><?php esc_html_e( 'Title (Emphasized)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hero_title_em" name="wescarhealth_hero_title_em" value="<?php echo esc_attr( get_option( 'wescarhealth_hero_title_em' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'This text will be styled differently (italic/accent color).', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hero_title_2"><?php esc_html_e( 'Title (Part 2)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hero_title_2" name="wescarhealth_hero_title_2" value="<?php echo esc_attr( get_option( 'wescarhealth_hero_title_2' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Text after the emphasized part.', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hero_description"><?php esc_html_e( 'Description', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<textarea id="wescarhealth_hero_description" name="wescarhealth_hero_description" rows="3" class="large-text"><?php echo esc_textarea( get_option( 'wescarhealth_hero_description' ) ); ?></textarea>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hero_cta_text"><?php esc_html_e( 'Primary Button Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hero_cta_text" name="wescarhealth_hero_cta_text" value="<?php echo esc_attr( get_option( 'wescarhealth_hero_cta_text' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_hero_cta_secondary"><?php esc_html_e( 'Secondary Button Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_hero_cta_secondary" name="wescarhealth_hero_cta_secondary" value="<?php echo esc_attr( get_option( 'wescarhealth_hero_cta_secondary' ) ); ?>" class="regular-text">
							</td>
						</tr>
					</table>
				</div>

				<!-- Trust Badge -->
				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'Trust Badge', 'wescarhealth-content' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_trust_rating"><?php esc_html_e( 'Rating', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_trust_rating" name="wescarhealth_trust_rating" value="<?php echo esc_attr( get_option( 'wescarhealth_trust_rating' ) ); ?>" class="small-text">
								<p class="description"><?php esc_html_e( 'e.g., "5.0"', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_trust_text"><?php esc_html_e( 'Trust Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_trust_text" name="wescarhealth_trust_text" value="<?php echo esc_attr( get_option( 'wescarhealth_trust_text' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'e.g., "Trusted by"', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_trust_count"><?php esc_html_e( 'Patient Count', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_trust_count" name="wescarhealth_trust_count" value="<?php echo esc_attr( get_option( 'wescarhealth_trust_count' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'e.g., "500+ patients"', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<!-- About Section -->
				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'About Section', 'wescarhealth-content' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_about_badge"><?php esc_html_e( 'Badge Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_about_badge" name="wescarhealth_about_badge" value="<?php echo esc_attr( get_option( 'wescarhealth_about_badge' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_about_title"><?php esc_html_e( 'Title', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_about_title" name="wescarhealth_about_title" value="<?php echo esc_attr( get_option( 'wescarhealth_about_title' ) ); ?>" class="large-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_about_description"><?php esc_html_e( 'Description', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<textarea id="wescarhealth_about_description" name="wescarhealth_about_description" rows="4" class="large-text"><?php echo esc_textarea( get_option( 'wescarhealth_about_description' ) ); ?></textarea>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_about_list_1"><?php esc_html_e( 'Feature 1', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_about_list_1" name="wescarhealth_about_list_1" value="<?php echo esc_attr( get_option( 'wescarhealth_about_list_1' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_about_list_2"><?php esc_html_e( 'Feature 2', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_about_list_2" name="wescarhealth_about_list_2" value="<?php echo esc_attr( get_option( 'wescarhealth_about_list_2' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_about_list_3"><?php esc_html_e( 'Feature 3', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_about_list_3" name="wescarhealth_about_list_3" value="<?php echo esc_attr( get_option( 'wescarhealth_about_list_3' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_about_cta_text"><?php esc_html_e( 'Button Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_about_cta_text" name="wescarhealth_about_cta_text" value="<?php echo esc_attr( get_option( 'wescarhealth_about_cta_text' ) ); ?>" class="regular-text">
							</td>
						</tr>
					</table>
				</div>

				<!-- Stats Section -->
				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'Stats Section', 'wescarhealth-content' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Edit the statistics displayed in the "Our Impact" section.', 'wescarhealth-content' ); ?></p>

					<?php for ( $i = 1; $i <= 4; $i++ ) : ?>
					<h3><?php printf( esc_html__( 'Stat %d', 'wescarhealth-content' ), $i ); ?></h3>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_number"><?php esc_html_e( 'Number', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_number" name="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_number" value="<?php echo esc_attr( get_option( 'wescarhealth_stat_' . $i . '_number' ) ); ?>" class="small-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_suffix"><?php esc_html_e( 'Suffix', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_suffix" name="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_suffix" value="<?php echo esc_attr( get_option( 'wescarhealth_stat_' . $i . '_suffix' ) ); ?>" class="small-text">
								<p class="description"><?php esc_html_e( 'e.g., "+", "%", "/7"', 'wescarhealth-content' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_label"><?php esc_html_e( 'Label', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_label" name="wescarhealth_stat_<?php echo esc_attr( $i ); ?>_label" value="<?php echo esc_attr( get_option( 'wescarhealth_stat_' . $i . '_label' ) ); ?>" class="regular-text">
							</td>
						</tr>
					</table>
					<?php endfor; ?>
				</div>

				<!-- CTA Section -->
				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'Call to Action Section', 'wescarhealth-content' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_cta_title"><?php esc_html_e( 'Title', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_cta_title" name="wescarhealth_cta_title" value="<?php echo esc_attr( get_option( 'wescarhealth_cta_title' ) ); ?>" class="large-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_cta_description"><?php esc_html_e( 'Description', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<textarea id="wescarhealth_cta_description" name="wescarhealth_cta_description" rows="2" class="large-text"><?php echo esc_textarea( get_option( 'wescarhealth_cta_description' ) ); ?></textarea>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_cta_button_text"><?php esc_html_e( 'Button Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_cta_button_text" name="wescarhealth_cta_button_text" value="<?php echo esc_attr( get_option( 'wescarhealth_cta_button_text' ) ); ?>" class="regular-text">
							</td>
						</tr>
					</table>
				</div>

				<?php submit_button( __( 'Save Settings', 'wescarhealth-content' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the coming soon settings page.
	 */
	public function render_coming_soon_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_GET['settings-updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			add_settings_error(
				'wescarhealth_messages',
				'wescarhealth_message',
				__( 'Settings saved.', 'wescarhealth-content' ),
				'updated'
			);
		}

		?>
		<div class="wrap wescarhealth-admin">
			<h1><?php esc_html_e( 'Coming Soon Page Content', 'wescarhealth-content' ); ?></h1>

			<?php settings_errors( 'wescarhealth_messages' ); ?>

			<div class="wescarhealth-admin__intro">
				<p><?php esc_html_e( 'Edit the text content displayed on the Coming Soon page.', 'wescarhealth-content' ); ?></p>
			</div>

			<form action="options.php" method="post">
				<?php settings_fields( 'wescarhealth_coming_soon' ); ?>

				<div class="wescarhealth-admin__section">
					<h2><?php esc_html_e( 'Page Content', 'wescarhealth-content' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="wescarhealth_coming_soon_badge"><?php esc_html_e( 'Badge Text', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_coming_soon_badge" name="wescarhealth_coming_soon_badge" value="<?php echo esc_attr( get_option( 'wescarhealth_coming_soon_badge' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_coming_soon_title_1"><?php esc_html_e( 'Title (Part 1)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_coming_soon_title_1" name="wescarhealth_coming_soon_title_1" value="<?php echo esc_attr( get_option( 'wescarhealth_coming_soon_title_1' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_coming_soon_title_em"><?php esc_html_e( 'Title (Emphasized)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_coming_soon_title_em" name="wescarhealth_coming_soon_title_em" value="<?php echo esc_attr( get_option( 'wescarhealth_coming_soon_title_em' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_coming_soon_title_2"><?php esc_html_e( 'Title (Part 2)', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<input type="text" id="wescarhealth_coming_soon_title_2" name="wescarhealth_coming_soon_title_2" value="<?php echo esc_attr( get_option( 'wescarhealth_coming_soon_title_2' ) ); ?>" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="wescarhealth_coming_soon_description"><?php esc_html_e( 'Description', 'wescarhealth-content' ); ?></label>
							</th>
							<td>
								<textarea id="wescarhealth_coming_soon_description" name="wescarhealth_coming_soon_description" rows="4" class="large-text"><?php echo esc_textarea( get_option( 'wescarhealth_coming_soon_description' ) ); ?></textarea>
							</td>
						</tr>
					</table>
				</div>

				<?php submit_button( __( 'Save Settings', 'wescarhealth-content' ) ); ?>
			</form>
		</div>
		<?php
	}
}
