<?php
/**
 * Helper functions for WesCarr Health Content plugin.
 *
 * @package WescarHealthContent
 */

declare(strict_types=1);

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Helper class with static methods for retrieving content.
 */
class WescarHealth_Content_Helpers {

	/**
	 * Get default values for all settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_defaults(): array {
		return array(
			// Contact Information.
			'phone'            => '(888) 456-7890',
			'email'            => 'info@wescarrhealth.com',
			'hours'            => '6am - Midnight, 7 Days',
			'hours_short'      => '6am - Midnight',
			'booking_url'      => 'https://www.tebra.com/',

			// Social Media.
			'facebook_url'     => 'https://facebook.com',
			'instagram_url'    => 'https://instagram.com',
			'linkedin_url'     => 'https://linkedin.com',
			'twitter_url'      => '',
			'youtube_url'      => '',

			// Branding.
			'site_name'        => 'WesCarr Health Hub',
			'site_tagline'     => 'Telehealth Made Simple',

			// Hero Section.
			'hero_badge'       => 'Telehealth Made Simple',
			'hero_title_1'     => 'Your Trusted Partner in',
			'hero_title_em'    => 'Modern Telehealth',
			'hero_title_2'     => 'Care',
			'hero_description' => 'Expert surgical clearance, hormone therapy, urgent care, and preventive health — all from the comfort of your home.',
			'hero_cta_text'    => 'Schedule Your Appointment',
			'hero_cta_secondary' => 'View Our Services',

			// About Section (Front Page).
			'about_badge'      => 'About Us',
			'about_title'      => 'Delivering Medical Excellence With A Personal Touch',
			'about_description' => 'WesCarr Health Hub is a veteran-led, board-certified telehealth practice dedicated to making healthcare accessible, reliable, and patient-centered. Our providers bring decades of combined experience in clinical practice, surgical support, and wellness care.',
			'about_list_1'     => 'Seamless online scheduling',
			'about_list_2'     => 'Same-day surgical clearance turnaround',
			'about_list_3'     => 'Compassionate, confidential care',
			'about_cta_text'   => 'Learn More About Us',

			// Stats Section.
			'stat_1_number'    => '500',
			'stat_1_suffix'    => '+',
			'stat_1_label'     => 'Patients Served',
			'stat_2_number'    => '98',
			'stat_2_suffix'    => '%',
			'stat_2_label'     => 'Satisfaction Rate',
			'stat_3_number'    => '24',
			'stat_3_suffix'    => '/7',
			'stat_3_label'     => 'Availability',
			'stat_4_number'    => '15',
			'stat_4_suffix'    => '+',
			'stat_4_label'     => 'Years Experience',

			// CTA Section.
			'cta_title'        => 'Ready to Get Started?',
			'cta_description'  => 'Schedule your telehealth appointment today and experience healthcare on your terms.',
			'cta_button_text'  => 'Book Your Appointment',

			// Trust Badge.
			'trust_rating'     => '5.0',
			'trust_text'       => 'Trusted by',
			'trust_count'      => '500+ patients',

			// Coming Soon Page.
			'coming_soon_badge'       => 'Coming Soon',
			'coming_soon_title_1'     => 'Something',
			'coming_soon_title_em'    => 'Amazing',
			'coming_soon_title_2'     => 'Is On The Way',
			'coming_soon_description' => 'We\'re working hard to bring you expert telehealth services. Stay tuned for surgical clearance, hormone therapy, urgent care, and preventive health — all from the comfort of your home.',
		);
	}

	/**
	 * Get a single setting value.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Default value if not set.
	 * @return mixed
	 */
	public static function get( string $key, $default = '' ) {
		$defaults = self::get_defaults();
		$fallback = $default ?: ( $defaults[ $key ] ?? '' );

		return get_option( 'wescarhealth_' . $key, $fallback );
	}

	/**
	 * Get phone number.
	 *
	 * @return string
	 */
	public static function get_phone(): string {
		return (string) self::get( 'phone' );
	}

	/**
	 * Get phone number formatted for tel: link.
	 *
	 * @return string
	 */
	public static function get_phone_link(): string {
		$phone = self::get_phone();
		// Remove all non-numeric characters except +.
		return preg_replace( '/[^0-9+]/', '', $phone ) ?: '';
	}

	/**
	 * Get email address.
	 *
	 * @return string
	 */
	public static function get_email(): string {
		return (string) self::get( 'email' );
	}

	/**
	 * Get hours of operation.
	 *
	 * @param bool $short Whether to return short version.
	 * @return string
	 */
	public static function get_hours( bool $short = false ): string {
		return (string) self::get( $short ? 'hours_short' : 'hours' );
	}

	/**
	 * Get booking URL.
	 *
	 * @return string
	 */
	public static function get_booking_url(): string {
		return (string) self::get( 'booking_url' );
	}

	/**
	 * Get social media URL.
	 *
	 * @param string $platform Platform name (facebook, instagram, linkedin, twitter, youtube).
	 * @return string
	 */
	public static function get_social_url( string $platform ): string {
		return (string) self::get( $platform . '_url' );
	}

	/**
	 * Get all social media URLs.
	 *
	 * @return array<string, string>
	 */
	public static function get_social_urls(): array {
		return array(
			'facebook'  => self::get_social_url( 'facebook' ),
			'instagram' => self::get_social_url( 'instagram' ),
			'linkedin'  => self::get_social_url( 'linkedin' ),
			'twitter'   => self::get_social_url( 'twitter' ),
			'youtube'   => self::get_social_url( 'youtube' ),
		);
	}

	/**
	 * Get hero section content.
	 *
	 * @return array<string, string>
	 */
	public static function get_hero(): array {
		return array(
			'badge'         => (string) self::get( 'hero_badge' ),
			'title_1'       => (string) self::get( 'hero_title_1' ),
			'title_em'      => (string) self::get( 'hero_title_em' ),
			'title_2'       => (string) self::get( 'hero_title_2' ),
			'description'   => (string) self::get( 'hero_description' ),
			'cta_text'      => (string) self::get( 'hero_cta_text' ),
			'cta_secondary' => (string) self::get( 'hero_cta_secondary' ),
		);
	}

	/**
	 * Get about section content.
	 *
	 * @return array<string, string>
	 */
	public static function get_about(): array {
		return array(
			'badge'       => (string) self::get( 'about_badge' ),
			'title'       => (string) self::get( 'about_title' ),
			'description' => (string) self::get( 'about_description' ),
			'list_1'      => (string) self::get( 'about_list_1' ),
			'list_2'      => (string) self::get( 'about_list_2' ),
			'list_3'      => (string) self::get( 'about_list_3' ),
			'cta_text'    => (string) self::get( 'about_cta_text' ),
		);
	}

	/**
	 * Get stats section content.
	 *
	 * @return array<int, array<string, string>>
	 */
	public static function get_stats(): array {
		return array(
			array(
				'number' => (string) self::get( 'stat_1_number' ),
				'suffix' => (string) self::get( 'stat_1_suffix' ),
				'label'  => (string) self::get( 'stat_1_label' ),
			),
			array(
				'number' => (string) self::get( 'stat_2_number' ),
				'suffix' => (string) self::get( 'stat_2_suffix' ),
				'label'  => (string) self::get( 'stat_2_label' ),
			),
			array(
				'number' => (string) self::get( 'stat_3_number' ),
				'suffix' => (string) self::get( 'stat_3_suffix' ),
				'label'  => (string) self::get( 'stat_3_label' ),
			),
			array(
				'number' => (string) self::get( 'stat_4_number' ),
				'suffix' => (string) self::get( 'stat_4_suffix' ),
				'label'  => (string) self::get( 'stat_4_label' ),
			),
		);
	}

	/**
	 * Get CTA section content.
	 *
	 * @return array<string, string>
	 */
	public static function get_cta(): array {
		return array(
			'title'       => (string) self::get( 'cta_title' ),
			'description' => (string) self::get( 'cta_description' ),
			'button_text' => (string) self::get( 'cta_button_text' ),
		);
	}

	/**
	 * Get trust badge content.
	 *
	 * @return array<string, string>
	 */
	public static function get_trust(): array {
		return array(
			'rating' => (string) self::get( 'trust_rating' ),
			'text'   => (string) self::get( 'trust_text' ),
			'count'  => (string) self::get( 'trust_count' ),
		);
	}

	/**
	 * Get coming soon page content.
	 *
	 * @return array<string, string>
	 */
	public static function get_coming_soon(): array {
		return array(
			'badge'       => (string) self::get( 'coming_soon_badge' ),
			'title_1'     => (string) self::get( 'coming_soon_title_1' ),
			'title_em'    => (string) self::get( 'coming_soon_title_em' ),
			'title_2'     => (string) self::get( 'coming_soon_title_2' ),
			'description' => (string) self::get( 'coming_soon_description' ),
		);
	}
}

/**
 * Global helper function to get content.
 *
 * @param string $key     Setting key.
 * @param mixed  $default Default value.
 * @return mixed
 */
function wescarhealth_get( string $key, $default = '' ) {
	return WescarHealth_Content_Helpers::get( $key, $default );
}

/**
 * Global helper function to echo escaped content.
 *
 * @param string $key     Setting key.
 * @param mixed  $default Default value.
 */
function wescarhealth_e( string $key, $default = '' ): void {
	echo esc_html( WescarHealth_Content_Helpers::get( $key, $default ) );
}
